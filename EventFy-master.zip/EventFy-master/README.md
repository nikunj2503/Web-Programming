# EventFy
462-Project

An idea implementation for an application that support creating and joining events.
